let nombre = 'Gerardo Ali Ferraro Schelijash';
let cedula = 15693289;
let valor = true;

console.warn(`Hola ${nombre} tu cedula es ${cedula} y eres ${valor}`);

